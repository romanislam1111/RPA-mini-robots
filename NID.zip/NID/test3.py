from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time 
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager

def etin_verification():
    
    # driver = webdriver.Chrome() 
    driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
    driver.get("https://verification.taxofficemanagement.gov.bd")
    
    
    etin_number = driver.find_element(By.XPATH,  "//*[@placeholder='TIN']")
    etin_number2 = driver.find_element(By.XPATH, "//*[@placeholder='Enter Captcha Code']")
    etin_number.send_keys("123456789012") 
    etin_number2.send_keys("AUTO") #Still working on it
    
    # Submit the e-TIN number for verification
    etin_number.send_keys(Keys.RETURN)
    
    
    time.sleep(3)
    
    # # Get the result of the e-TIN verification
    # result = driver.find_element(By.XPATH, "//div[@id='result']").text
    # print(result)
    
    driver.close()

etin_verification()