from base import BasePage
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

class EmailShooter(BasePage):
    def __init__(self, driver: webdriver, max_wait=15) -> None:
        super().__init__(driver, max_wait)

    
    def goto_gmail(self):
        self.goto_page("https://mail.google.com/mail/u/0/#inbox")
        self.driver.maximize_window()
        
    def enter_email_and_go_next(self, email_id):
        email = self.get_element( "//input[@id='identifierId']") 
        email.send_keys(email_id) 
        email.send_keys(Keys.RETURN)
        time.sleep(2)

    def enter_password_and_submit(self, pwd):
        email = self.get_element( "//*[@name='Passwd']") 
        email.send_keys(pwd) 
        email.send_keys(Keys.RETURN)


from selenium.webdriver.chrome.options import Options
chrome_options = Options()
chrome_options.add_experimental_option("detach", True)

chrome = webdriver.Chrome("chromedriver.exe", options=chrome_options)

es = EmailShooter(driver=chrome)
es.goto_gmail()
es.enter_email_and_go_next("md.roman.islam@g.bracu.ac.bd")
es.enter_password_and_submit("1910159607882712")