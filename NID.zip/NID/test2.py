from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time 
import os

def etin_verification():
    #driver = webdriver.Chrome('C:\Users\roman32846\.cache\selenium\chromedriver\win32\109.0.5414.74\chromedriver.exe')
    driver = webdriver.Chrome("chromedriver.exe")
    driver.get("https://accounts.google.com/v3/signin/identifier?dsh=S1980343503%3A1676193623016056&elo=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin&ifkv=AWnogHfL1kBEDCYL61xVfE4f8s-qup9H4w82mUewcXKZjGwwDujNN9qRHVry0cYp-_lRbSfDQ_72")
    
    
    email = driver.find_element(By.XPATH,  "//input[@id='identifierId']")
    #etin_number2 = driver.find_element(By.XPATH, "//*[@placeholder='Enter Captcha Code']")
    email.send_keys("md.roman.islam@g.bracu.ac.bd") 
    #etin_number2.send_keys("AUTO") #Still working on it
    
    # Submit the e-TIN number for verification
    email.send_keys(Keys.RETURN)
    
    passcode = driver.find_element(By.XPATH,  "//input[@id='passwordNext']/span/span")
    passcode.send_keys("1910159607882712") 
    passcode.send_keys(Keys.RETURN)
    
    time.sleep(3)
    #driver.implicitly_wait(40)
    
    # # Get the result of the e-TIN verification
    # result = driver.find_element(By.XPATH, "//div[@id='result']").text
    # print(result)
    
    driver.close()

etin_verification()