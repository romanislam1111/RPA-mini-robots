from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

class BasePage:

    def __init__(self, driver, max_wait=15) -> None:
        self.driver = driver
        self.max_wait = max_wait


    def get_element(self, xpath):
        time.sleep(1)
        element = WebDriverWait(self.driver, self.max_wait).until(
            EC.presence_of_element_located((By.XPATH, xpath)))
        return element
        
    def goto_page(self, url):
        self.driver.get(url)