import os
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

chromedriver_path = "chromedriver.exe"


os.environ["webdriver.chrome.driver"] = chromedriver_path

try:
    driver = webdriver.Chrome(chromedriver_path)
except Exception as e:
    print("ChromeDriver executable needs to be in PATH. Error: ", e)
    exit()


driver.get("https://gmail.com")


email = driver.find_element(By.XPATH,  "//input[@id='identifierId']")
email.send_keys("md.roman.islam@g.bracu.ac.com")
email.send_keys(Keys.RETURN)


wait = WebDriverWait(driver, 10) #Explicit
password = wait.until(EC.presence_of_element_located((By.XPATH, "//input[@type='password']")))
password.send_keys("yourpassword")
password.send_keys(Keys.RETURN)


wait.until(EC.title_contains("Inbox"))


compose_button = driver.find_element(By.XPATH, ("//div[text('Compose']"))
compose_button.click()

to_field = driver.find_element_by_name("to")
to_field.send_keys("opuroman@gmail.com")

subject_field = driver.find_element_by_name("subjectbox")
subject_field.send_keys("Tester")

body_field = driver.find_element_by_xpath("//div[@role='textbox']")
body_field.send_keys("Hola Brazil")

send_button = driver.find_element(By.XPATH, ("//div[text('Send']"))
send_button.click()


driver.quit()