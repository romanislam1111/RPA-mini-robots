import os
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC 
from selenium.webdriver.chrome.service import Service as ChromeService 
from webdriver_manager.chrome import ChromeDriverManager

#chromedriver_path = "chromedriver.exe"


#os.environ["webdriver.chrome.driver"] = chromedriver_path

# try:
#     driver = webdriver.Chrome(chromedriver_path)
# except Exception as e:
#     print("ChromeDriver executable needs to be in PATH. Error: ", e)
#     exit()


driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
driver.get("https://accounts.google.com/v3/signin/identifier?dsh=S1980343503%3A1676193623016056&elo=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin&ifkv=AWnogHfL1kBEDCYL61xVfE4f8s-qup9H4w82mUewcXKZjGwwDujNN9qRHVry0cYp-_lRbSfDQ_72")


# Login to Gmail
username = driver.find_element_by_xpath("//input[@type='email']")
username.send_keys("your_email@gmail.com")
username.send_keys(Keys.RETURN)

password = driver.find_element_by_xpath("//input[@type='password']")
password.send_keys("your_password")
password.send_keys(Keys.RETURN)

# Compose and send an email
compose_button = driver.find_element_by_xpath("//div[text()='Compose']")
compose_button.click()

to_field = driver.find_element_by_xpath("//textarea[@name='to']")
to_field.send_keys("recipient_email@gmail.com")

subject_field = driver.find_element_by_xpath("//input[@name='subjectbox']")
subject_field.send_keys("Subject of the email")

body_field = driver.find_element_by_xpath("//div[@aria-label='Message Body']")
body_field.send_keys("Body of the email")

send_button = driver.find_element_by_xpath("//div[text()='Send']")
send_button.click()

# Quit the driver
driver.quit()