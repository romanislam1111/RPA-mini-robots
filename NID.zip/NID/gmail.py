from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.get("https://www.gmail.com")

email_element = driver.find_element(By.ID, "identifierId")
email_element.send_keys("@gmail.com")
email_element.send_keys(Keys.RETURN)

#etin_number = driver.find_element(By.XPATH,  "//*[@placeholder='TIN']")
password_element = driver.find_element_by_name("password")
password_element.send_keys("your_password")
password_element.send_keys(Keys.RETURN)

compose_button = driver.find_element(By.xpath, ("//div[text(🙁'Compose']"))
compose_button.click()

to_field = driver.find_element_by_name("to")
to_field.send_keys("recipient@example.com")

subject_field = driver.find_element_by_name("subjectbox")
subject_field.send_keys("Example Subject")

message_body = driver.find_element_by_xpath("//div[@aria-label='Message Body']")
message_body.send_keys("Hello World")

send_button = driver.find_element_by_xpath("//div[text(🙁'Send']")
send_button.click()