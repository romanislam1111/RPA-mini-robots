from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time 
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager 
from selenium.webdriver.support import expected_conditions as EC 


def etin_verification():
    
    # driver = webdriver.Chrome() 
    driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
    driver.get("https://accounts.google.com/v3/signin/identifier?dsh=S1980343503%3A1676193623016056&elo=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin&ifkv=AWnogHfL1kBEDCYL61xVfE4f8s-qup9H4w82mUewcXKZjGwwDujNN9qRHVry0cYp-_lRbSfDQ_72")
    
    
    
    email = driver.find_element(By.XPATH,  "//input[@id='identifierId']") 
    passw = driver.find_element(By.XPATH, "//input[@type='password']")

    email.send_keys("md.roman.islam@g.bracu.ac.com")
    email.send_keys(Keys.RETURN) 

    passw.send_keys("1910159607882712")
    passw.send_keys(Keys.RETURN) 

    # wait = WebDriverWait(driver, 30) #Explicit
    # password = wait.until(EC.presence_of_element_located((By.XPATH, "//input[@type='password']")))
    # password.send_keys("yourpassword")
    # password.send_keys(Keys.RETURN)
    # etin_number2 = driver.find_element(By.XPATH, "//*[@placeholder='Enter Captcha Code']")
    # etin_number.send_keys("123456789012") 
    # etin_number2.send_keys("AUTO") #Still working on it
    
    # Submit the e-TIN number for verification
    #etin_number.send_keys(Keys.RETURN)
    
    
    time.sleep(3)
    
    # # Get the result of the e-TIN verification
    # result = driver.find_element(By.XPATH, "//div[@id='result']").text
    # print(result)
    
    driver.close()

etin_verification()